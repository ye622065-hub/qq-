@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Node is not on this machine's system PATH, so use the Node bundled with the
rem DSH runtime. Behaviour otherwise matches start.bat: daemon mode, restart 5s
rem after a crash, closing this window stops it. Kept pure ASCII because cmd.exe
rem decodes batch files with the local code page.
set "NODE_DIR=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin"
if not exist "%NODE_DIR%\node.exe" (
    echo [ERROR] bundled Node not found: %NODE_DIR%\node.exe
    echo         Install Node 22.13+ system-wide, or edit NODE_DIR in this file.
    pause
    exit /b 1
)
set "PATH=%NODE_DIR%;%PATH%"

node scripts\harden-state-acl.mjs --quiet
:loop
node src\bridge.js
set code=%errorlevel%
if "%code%"=="2" (
    echo [%date% %time%] another instance is already running; exiting.
    pause
    exit /b 2
)
echo [%date% %time%] bridge exited (code %code%), restarting in 5 seconds...
timeout /t 5 /nobreak >nul
goto loop
